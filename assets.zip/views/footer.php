<footer>
    <p>Contacto: contacto@viajescolombia.com | Tel: +57 300 1234567</p>
    <p>© 2025 Viajes Colombia</p>
</footer>
</body>
</html>